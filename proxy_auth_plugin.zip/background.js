
    var config = {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "us-ca.proxymesh.com",
                    port: parseInt(31280)
                },
                bypassList: ["localhost"]
            }
        };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "harsha6174",
                    password: "Elliegoulding1173"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    